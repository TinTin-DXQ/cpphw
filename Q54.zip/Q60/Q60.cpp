#include <iostream>
#include <vector>
#include <string>
#include <sstream>
using namespace std;

string to_str(int i) {
	stringstream ss;
	ss << i;
	string s;
	ss >> s;
	return s;
}

class Car {
public:
	string type="";
	double occupiedUnit=0.0;
	int occupiedTime=0;
	int waitTime=0;
	double fare=0.0;
	int id=0;
	virtual void setType(string t) {
		type = t;
	}
	virtual void setUnit(double u) {
		occupiedUnit = u;
	}
	virtual void setOTime(int ot) {
		occupiedTime = ot;
	}
	virtual void setWTime(int wt) {
		waitTime = wt;
	}
	virtual void setFare(double f) {
		fare = f;
	}
	virtual void setId(int i) {
		id = i;
	}
};

class Scar :public Car {
public:
	Scar(int id) {
		setType("S");
		setUnit(1.0);
		setOTime(3);
		setWTime(1);
		setFare(1.5);
		setId(id);
	}
};

class Mcar :public Car {
public:
	Mcar(int id) {
		setType("M");
		setUnit(1.5);
		setOTime(2);
		setWTime(2);
		setFare(3.0);
		setId(id);
	}
};

class Lcar :public Car {
public:
	Lcar(int id) {
		setType("L");
		setUnit(2.0);
		setOTime(1);
		setWTime(3);
		setFare(4.5);
		setId(id);
	}
};

class ParkingSpace {
public:
	string space;
	ParkingSpace() {
		space = "";
	}
};

class PTime {
public:
	Car* car=NULL;
	int time=0;
	PTime(Car* c, int t) :car(c), time(t) {}
};


class ParkingLot {
public:
	double total=0.0;
	vector<ParkingSpace*> parkingSpace;	
	vector<PTime*> waitingCars;
	vector<PTime*> parkingCars;
	vector<Car*> cars;
	ParkingLot(int n) {
		for (int i = 0; i < (2*n); ++i) {
			parkingSpace.push_back(new ParkingSpace());
		}
	}

	void noPark(int presentTime, double * freeSpace) {
		vector<int> tempId;
		vector<string> tempType;
		vector<string> tempTi;
		for (PTime* pi : parkingCars) {
			if (presentTime - pi->time >= pi->car->occupiedTime) {
				tempId.push_back(pi->car->id);
				tempType.push_back(pi->car->type);
				tempTi.push_back(pi->car->type + to_str(pi->car->id));
			}
		}
		int loop = tempId.size();
		for (int i = 0; i < loop; ++i) {
			for (int j = 0; j < parkingCars.size(); ++j) {
				if (parkingCars[j]->car->id == tempId[0] && parkingCars[j]->car->type == tempType[0]) {
					if (parkingCars[j]->car->type == "S") {
						*freeSpace += 1.0;
					}
					else if (parkingCars[j]->car->type == "M") {
						*freeSpace += 1.5;
					}
					else {
						*freeSpace += 2.0;
					}
					parkingCars.erase(parkingCars.begin() + j);
					for (ParkingSpace* ps : parkingSpace) {
						if (ps->space == tempTi[0]) {
							ps->space = "";
						}
					}
					break;
				}
			}
			tempId.erase(tempId.begin());
			tempType.erase(tempType.begin());
			tempTi.erase(tempTi.begin());
		}

	}
	void noWait(int presentTime) {
		vector<int> tempId;
		vector<string> tempType;
		for (PTime* pi : waitingCars) {
			if (presentTime - pi->time >= pi->car->waitTime) {
				tempId.push_back(pi->car->id);
				tempType.push_back(pi->car->type);
			}
		}
		int loop = tempId.size();
		for (int i = 0; i < loop; ++i) {
			for (int j = 0; j < waitingCars.size(); ++j) {
				if (waitingCars[j]->car->id == tempId[0] && waitingCars[j]->car->type == tempType[0]) {
					waitingCars.erase(waitingCars.begin() + j);
					break;
				}
			}
			tempId.erase(tempId.begin());
			tempType.erase(tempType.begin());
		}
	}
	
	void sunny() {
		int presentTime = 0;
		double freespace = parkingSpace.size() / 2;

		while (true) {
			presentTime++;
			if (parkingCars.size() == 0 && waitingCars.size() == 0&&cars.size()==0) {
				break;
			}
			if (cars.size() > 0) {
				waitingCars.push_back(new PTime(cars[0], presentTime));
				cars.erase(cars.begin());
			}
			this->noWait(presentTime);			
			this->noPark(presentTime, &freespace);

			while (waitingCars.size() > 0) {
				PTime* ptime = waitingCars[0];
				if (freespace >= ptime->car->occupiedUnit) {
					waitingCars.erase(waitingCars.begin());
					ptime->time = presentTime;
					parkingCars.push_back(ptime);
					total += ptime->car->fare;
					freespace -= ptime->car->occupiedUnit;
				}
				else {
					break;
				}
			}
			for (int i = 0; i < parkingCars.size(); ++i) {
				if (i==parkingCars.size()-1) {
					cout << parkingCars[i]->car->type + to_str(parkingCars[i]->car->id)<<endl;
				}
				else {
					cout<< parkingCars[i]->car->type + to_str(parkingCars[i]->car->id) <<" ";
				}
			}
			if (parkingCars.size() < 1) {
				cout << "null" << endl;
			}
		}
	}
};

int main() {
	int num,intid;
	string op, type, id, weather;
	cin >> num;
	cin>> weather;
	ParkingLot parkingLot(num);
	while (true) {
		cin >> op;
		if (op == "end"){
			break;
		}
		cin >> type>> id;
	
		intid = stoi(id.substr(1,id.size()).c_str());
		//cout << intid;
		if (type == "S") {
			parkingLot.cars.push_back(new Scar(intid));
		}
		else if (type == "M") {
			parkingLot.cars.push_back(new Mcar(intid));
		}
		else{
			parkingLot.cars.push_back(new Lcar(intid));
		}

	}
	if (weather == "sunny") {
		parkingLot.sunny();
	}

	cout << parkingLot.total;
	getchar();
	getchar();
}