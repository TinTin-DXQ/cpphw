#include <iostream>
using namespace std;

class Hamber {
public:
	virtual int getCost() = 0;
private:
	int meatNum;
	int vegNum;
};

class Beef :public Hamber {
public:
	int meatNum;
	Beef() :meatNum(0){}
	Beef(int num) :meatNum(num) {}
	int getCost() {
		return 10* meatNum;
	}
};

class Pork :public Hamber {
public:
	int meatNum;
	Pork():meatNum(0){}
	Pork(int num):meatNum(num){}
	int getCost() {
		return 8* meatNum;
	}
};

class Chick :public Hamber {
public:
	int meatNum;
	Chick():meatNum(0){}
	Chick(int num):meatNum(num){}
	int getCost() {
		return 7* meatNum;
	}
};

class HamberDecorator :public Hamber {
public: 
	int vegNum;
	HamberDecorator(Hamber* hamber) :m_hamber(hamber),vegNum(0) {};
	HamberDecorator(Hamber* hamber,int num) :m_hamber(hamber),vegNum(num){};
	int getCost() {
		return m_hamber->getCost();
	}
public:
	Hamber* m_hamber;
};

class LettuceDecorator :public HamberDecorator {
public:
	int vegNum;
	LettuceDecorator(Hamber* hamber) :HamberDecorator(hamber), vegNum(0){};
	LettuceDecorator(Hamber* hamber,int num) :HamberDecorator(hamber), vegNum(num){};
	int getCost() {
		return m_hamber->getCost() + 4* vegNum;
	}
};

class TomatoDecorator :public HamberDecorator {
public:
	int vegNum;
	TomatoDecorator(Hamber* hamber) :HamberDecorator(hamber), vegNum(0){};
	TomatoDecorator(Hamber* hamber,int num) :HamberDecorator(hamber), vegNum(num){};
	int getCost() {
		return m_hamber->getCost() + 3* vegNum;
	}
};

int main() {
	Hamber* hamber;
	Hamber* hamberDecorator;
	int meatName=0;
	int meatNum=0;
	int vegName=0;
	int vegNum=0;
	cin >> meatName;
	cin >> meatNum;
	cin >> vegName;
	cin >> vegNum;

	if (meatName == 1) {
		hamber = new Beef(meatNum);
	}
	else if (meatName == 2) {
		hamber = new Pork(meatNum);
	}
	else{
		hamber = new Chick(meatNum);
	}
	if (vegName == 1) {
		hamberDecorator = new LettuceDecorator(hamber,vegNum);
	}
	else{
		hamberDecorator = new TomatoDecorator(hamber, vegNum);
	}
	cout << hamberDecorator->getCost();
	getchar();
	getchar();
}