#include <iostream>
#include <List>
using namespace std;

class Food {
public:
	double carbohydrate=0.0;
	double protein=0.0;
	double df=0.0;
	double fat=0.0;
	void setcar(double c) {
		carbohydrate = c;
	}
	void setpro(double p) {
		protein = p;
	}
	void setdf(double d) {
		df = d;
	}
	void setfat(double f) {
		fat = f;
	}
};

class Rice :public Food {
public:
	Rice() {
		Food::setcar(16.2);
		Food::setpro(3.7);
		Food::setdf(0.0);
		Food::setfat(0.0);
	}
};

class Beef :public Food {
public:
	Beef() {
		Food::setcar(1.8);
		Food::setpro(17.5);
		Food::setdf(0.0);
		Food::setfat(7.2);
	}
};

class Bro :public Food {
public:
	Bro() {
		Food::setcar(0.2);
		Food::setpro(0.4);
		Food::setdf(3.6);
		Food::setfat(0.0);
	}
};

class Oat :public Food {
public:
	Oat() {
		Food::setcar(12.3);
		Food::setpro(5.7);
		Food::setdf(7.3);
		Food::setfat(3.0);
	}
};

class Duck :public Food {
public:
	Duck() {
		Food::setcar(6.9);
		Food::setpro(9);
		Food::setdf(0.0);
		Food::setfat(9.3);
	}
};

class Cab :public Food {
public:
	Cab() {
		Food::setcar(2.1);
		Food::setpro(0.8);
		Food::setdf(4.3);
		Food::setfat(0.0);
	}
};

class Diet {
public:
	list<Food*> foodList;
	friend Diet& operator+=(Diet& diet, const Food*& food);
	int if_healthy() {
		double min_car = 13.3;
		double min_pro = 13.5;
		double min_df = 3.3;
		double max_fat = 10.3;
		double tcar = 0.0;
		double tpro = 0.0;
		double tdf = 0.0;
		double tfat = 0.0;
		for (Food* food : foodList) {
			tcar = food->carbohydrate + tcar;
			tpro = food->protein + tpro;
			tdf = food->df + tdf;
			tfat = food->fat + tfat;
		}
		//cout << tcar<<endl;
		//cout << tpro << endl;
		//cout << tdf << endl;
		//cout << tfat << endl;
		if (tcar >= min_car && tpro >= min_pro && tdf >= min_df && tfat <= max_fat) {
			return 1;
		}
		else {
			return 0;
		}
	}
};

Diet& operator+=(Diet& diet, Food*& food) {
	diet.foodList.push_back(food);
	return diet;
}

int main() {
	int name;
	Food* food;
	Diet diet;
	int isvalid = 0;
	for (int i = 0; i < 3; ++i) {
		cin >> name;
		if (name > 6) {
			isvalid = 1;
		}
		switch (name){
		case 1:
			food = new Rice;
			diet += food;
			break;
		case 2:
			food = new Beef;
			diet += food;
			break;
		case 3:
			food = new Bro;
			diet += food;
			break;
		case 4:
			food = new Oat;
			diet += food;
			break;
		case 5:
			food = new Duck;
			diet += food;
			break;
		default:
			food = new Cab;
			diet += food;
			break;
		}
	}
	if (isvalid == 1) {
		cout << -1;
	}
	else {
		int res = diet.if_healthy();
		if (res == 1) {
			cout << "healthy";
		}
		else {
			cout << "unhealthy";
		}
	}
	getchar();
	getchar();
}