#include <iostream>
#include <vector>
#include <string>
#include <iterator>
using namespace std;

class Rectangle {
public:
	int id;
	int red;
	int green;
	int blue;
	vector<int> group;
	double grey=0;
	Rectangle():id(0),red(0),green(0),blue(0),grey(0.0){}
	virtual void setColor(int r, int g, int b) {
		red = r;
		green = g;
		blue = b;
	}
	virtual void setId(int i) {
		id = i;
	}
	virtual void setGrey(int r, int g, int b) {
		grey = r * 0.299 + g * 0.587 + b * 0.114;
	}
	virtual void setGroup(int gro){
		group.push_back(gro);
	}

};

class Normal:public Rectangle {
public:
	Normal(int i) {
		Rectangle::setId(i);
	}
	void setColor(int r, int g, int b) {
		red = r;
		green = g;
		blue = b;
		this->setGrey(r, g, b);
	}
};

class Reverse :public Rectangle {
public:
	Reverse(int i) {
		Rectangle::setId(i);
	}
	void setColor(int r, int g, int b) {
		red = 255 - r;
		green = 255 - g;
		blue = 255 - b;
		this->setGrey(red, green, blue);
	}
};

class Single :public Rectangle {
public:
	Single(int i) {
		Rectangle::setId(i);
	}
	void setColor(int r, int g, int b) {
		red = r;
		green = 0;
		blue = 0;
		this->setGrey(red, green, blue);
	}
};

class Deal {
public:
	vector<Rectangle*> rectangles;
	Rectangle* getRec(int i) {
		for (Rectangle* r : rectangles) {
			if (r->id == i) {
				return r;
			}
		}
		return NULL;
	}

	void addRec(Rectangle* rec) {
		rectangles.push_back(rec);
	}

	void normalCommand() {
		vector<Rectangle*> tempRec;
		tempRec.push_back(rectangles[0]);
		int numRec = rectangles.size();

		for (int i = 1; i < numRec; ++i) {
			int tick = 0;
			for (int j = 0; j < tempRec.size(); ++j) {
				if (tempRec[j]->id > rectangles[i]->id) {
					tempRec.insert(tempRec.begin() + j, rectangles[i]);
					tick = 1;
					break;
				}
			}
			if (tick == 0) {
				tempRec.push_back(rectangles[i]);
			}
		}
		for (Rectangle* rec : tempRec) {
			cout << "P" << rec->id << " " << rec->red << " " << rec->green << " " << rec->blue<<endl;
		}
	}
	void grayCommand() {
		vector<Rectangle*> tempRec;
		tempRec.push_back(rectangles[0]);
		for (int i = 1; i < rectangles.size(); ++i) {
			int tick = 0;
			for (int j = 0; j < tempRec.size(); ++j) {
				if (tempRec[j]->grey > rectangles[i]->grey) {
					tempRec.insert(tempRec.begin() + j, rectangles[i]);
					tick = 1;
					break;
				}
				else if (tempRec[j]->grey == rectangles[i]->grey) {
					if (tempRec[j]->id > rectangles[i]->id) {
						tempRec.insert(tempRec.begin() + j, rectangles[i]);
						tick = 1;
						break;
					}
				}
			}
			if (tick == 0) {
				tempRec.push_back(rectangles[i]);
			}
		}
		for (Rectangle* rec : tempRec) {
			cout << "P" << rec->id << " " << rec->red << " " << rec->green << " " << rec->blue << endl;
		}
	}
};
/*
Deal& operator+=(Deal& deal, Rectangle*& rectangle) {
	deal.rectangles.push_back(rectangle);
	return deal;
}*/

int main() {
	int num;
	cin >> num;
	string op, type, id;
	int intid;
	Deal deal;
	int red=0, green=0, blue=0;
	for (int i = 0; i < num; ++i) {
		cin >> op;
		if (op == "Add") {
			cin >> type >> id;
			intid = stoi(id.substr(1, id.size()).c_str());
			if (type == "normal") {
				deal.addRec(new Normal(intid));
			}
			else if (type == "single") {
				deal.addRec(new Single(intid));
			}
			else {

				deal.addRec(new Reverse(intid));
			}
		}
		else if (op == "Set") {
			cin >> id >> red >> green >> blue;
			if (id[0] == 'P') {
				intid = stoi(id.substr(1, id.size()).c_str());
				Rectangle* rec = deal.getRec(intid);
				rec->setColor(red, green, blue);
			}
			else {
				intid = stoi(id.substr(1, id.size()).c_str());
				for (Rectangle* rec : deal.rectangles) {
					for (int gId : rec->group) {
						if (gId == intid) {
							rec->setColor(red, green, blue);
						}
					}
				}
			}
		}
		else if (op == "Group") {
			int numRec;
			string gId;
			vector<int> idGroup;
			cin >> numRec;
			for (int j= 0; j < numRec; ++j) {
				cin >> id;
				intid = stoi(id.substr(1, id.size()).c_str());
				idGroup.push_back(intid);
			}
			cin >> gId;
			int inigid= stoi(gId.substr(1, gId.size()).c_str());
			for (int j : idGroup) {
				Rectangle* rec = deal.getRec(j);
				rec->setGroup(inigid);
			}
		}
	}
	string command;
	cin >> command;
	if (command == "Normal") {
		deal.normalCommand();
	}
	else if(command=="Gray"){
		deal.grayCommand();
	}
	getchar();
	getchar();
}