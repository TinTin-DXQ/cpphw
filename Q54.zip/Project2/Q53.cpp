#include <iostream>
using namespace std;

class GPU
{
public:
	virtual double Calculate() = 0;
private:
	int price;	//�Կ��۸�
	int hashRate;	//�ṩ������
};

class GPU1:public GPU
{
public:	
	int price;
	int hashRate;
	double cost = 16.2;

	GPU1():price(0),hashRate(0){}
	GPU1(int price, int hashRate):price(price),hashRate(hashRate){}
	friend istream& operator>>(istream &is, GPU1 &gpu);
	double Calculate() {
		double res = hashRate * 0.02 - cost;
		return res;
	}
	int getPrice() {
		return price;
	}
};

class GPU2 :public GPU {
public:
	int price;
	int hashRate;
	double cost = 28.8;

	GPU2():price(0), hashRate(0) {}
	GPU2(int price, int hashRate) :price(price), hashRate(hashRate) {}
	friend istream& operator>>(istream &is, GPU2 &gpu);
	double Calculate() {
		double res = hashRate * 0.02 - cost;
		return res;
	}
	int getPrice() {
		return price;
	}
};

class GPU3 :public GPU {
public:
	int price;
	int hashRate;
	double cost = 19.44;

	GPU3():price(0), hashRate(0) {}
	GPU3(int price, int hashRate) :price(price), hashRate(hashRate) {}
	friend istream& operator>>(istream &is, GPU3 &gpu);
	double Calculate() {
		double res = hashRate * 0.02 - cost;
		return res;
	}
	int getPrice() {
		return price;
	}
};

istream &operator>>(istream &is, GPU1 &gpu) {
	is >> gpu.price >> gpu.hashRate;
	return is;
}
istream &operator>>(istream &is, GPU2 &gpu) {
	is >> gpu.price >> gpu.hashRate;
	return is;
}
istream &operator>>(istream &is, GPU3 &gpu) {
	is >> gpu.price >> gpu.hashRate;
	return is;
}

int main() {
	GPU1 gpu1;
	GPU2 gpu2;
	GPU3 gpu3;
	cin >> gpu1;
	cin >> gpu2;
	cin >> gpu3;
	double benefit = gpu1.Calculate() + gpu2.Calculate() + gpu3.Calculate();
	double cost = gpu1.getPrice() + gpu2.getPrice() + gpu3.getPrice();
	if (benefit <= 0) {
		cout << -1;
	}
	else {
		double days = cost / benefit;
		int temp = (int)days;
		if (temp < days) {
			cout << temp+1;
		}
		else {
			cout << temp;
		}
	}
	getchar();
	getchar();
}
