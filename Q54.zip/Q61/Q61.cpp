#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
using namespace std;

class Transaction {
public:
	int type;
	double amount;
	Transaction(int t, double a) :type(t), amount(a) {}
};

class Account {
public:
	int index;
	int type=0;
	double amount=0;
	vector<Transaction*> history;
	virtual void setIndex(int i) {
		index = i;
	}
	virtual void setType(int t) {
		type = t;
	}
	virtual void deposit(double a) {
		amount = amount+a;
		history.push_back(new Transaction(0, a));
	}
	virtual void  withdraw(double a) {
		if (a > amount) {
			cout << "sumTransactions must be greater than zero" << endl;
		}
		else {
			amount = amount - a;
			history.push_back(new Transaction(1, a));
		}
	}
	virtual double getInterest() {
		return NULL;


	};
	virtual double sumTranctions() {
		return amount;
	}
	virtual double getTotalDeposit() {
		double total = 0.0;
		for (Transaction* transaction : history) {
			if (transaction->type == 0) {
				total = total + transaction->amount;
			}
		}
		return total;
	}
	virtual double getTotalWithdraw() {
		double total = 0;
		for (Transaction* transaction : history) {
			if (transaction->type == 1) {
				total = total + transaction->amount;
			}
		}
		return total;
	}
};

class Check :public Account {
public:
	Check(int i) {
		setIndex(i);
		setType(0);
	}
	double getInterest() {
		return 0.001*amount;
	}
};

class Save :public Account {
public:
	Save(int i) {
		setIndex(i);
		setType(1);
	}
	double getInterest(){
		if (amount > 1000) {
			return 1000*0.001 + 0.002*(amount - 1000);
		}
		else {
			return 0.001*amount;
		}
	}
};

class Maxi_Savings :public Account {
public:
	Maxi_Savings(int i) {
		setIndex(i);
		setType(2);
	}
	double getInterest() {
		if (amount > 2000) {
			return 70.0 + 0.1*(amount - 2000);
		}
		else if (amount > 1000) {
			return 20.0 + 0.05*(amount - 1000);
		}
		else {
			return 0.02*amount;
		}
	}
};

class Client {
public:
	string name;
	vector<Account*> accounts;
	Client(string n):name(n){}

	void addAccount(Account* account) {
		accounts.push_back(account);
	}
	void deposit(int index, int n) {
		Account* account;
		for (Account* ac : accounts) {
			if (ac->index == index) {
				account = ac;
			}
		}
		account->deposit(n);
	}
	void withdraw(int index, int n) {
		Account* account;
		for (Account* ac : accounts) {
			if (ac->index == index) {
				account = ac;
			}
		}
		account->withdraw(n);
	}

	double getAllAccounts() {
		double total = 0;
		for (Account* account : accounts) {
			total = total + account->amount;
		}
		return total;
	}
	
	int getNumOfAccounts() {
		return accounts.size();
	}

	double getInterest() {
		double total = 0.0;
		for (Account* ac : accounts) {
			total = total + ac->getInterest();
		}
		return total;
	}

	void showStatement() {
		double deposit = 0.0;
		double withdraw = 0.0;
		cout << "Statement for "<<name<<endl;
		cout << endl;
		cout.setf(ios::fixed);
		cout << setprecision(2);
		for (Account* ac : accounts) {
			if (ac->type == 0) {
				cout << "Checking Account" << endl;
			}
			else if (ac->type == 1) {
				cout << "Savings Account" << endl;
			}
			else {
				cout << "Maxi-Saving Account" << endl;
			}
			double deposit = ac->getTotalDeposit();
			double withdraw = ac->getTotalWithdraw();
			if (deposit > 0) {
				cout << "  deposit $" << deposit << endl;
			}
			if (withdraw > 0) {
				cout << "  withdrawal $" << withdraw << endl;
			}
			cout << "Total $" << ac->sumTranctions() << endl<<endl;
		}
		cout << "Total In All Accounts $" << this->getAllAccounts()<<endl;
	}
};


class BankManager {
public:
	vector<Client*> clients;
	void addClient(Client* client) {
		clients.push_back(client);
	}

	Client* getClient(string name) {
		for (Client* client : clients) {
			if (client->name == name) {
				return client;
			}
		}
		return NULL;
	}

	int getClientAccount(string name) {
		for (Client* cli :clients) {
			if (cli->name == name) {
				return cli->getNumOfAccounts();
			}
		}
		return NULL;
	}

	void addAccountTwoClient(Account* account, string name) {
		for (Client* client : clients) {
			if (client->name == name) {
				client->addAccount(account);
				break;
			}
		}
	}

	void showClientStatement(string name) {
		for (Client* client : clients) {
			if (client->name == name) {
				client->showStatement();
			}
		}
	}

	void showClientSum() {
		cout << "Customer Summary" << endl;
		for (Client*cli : clients) {
			int num = cli->getNumOfAccounts();
			cout << "- " << cli->name << " (" << num << " ";
			if (num > 1) {
				cout << "accounts" << ")" << endl;
			}
			else {
				cout << "account" << ")" << endl;
			}
		}
	}

	double getClientInterest(string name) {
		for (Client* client : clients) {
			if (client->name == name) {
				return client->getInterest();
			}
		}
		return NULL;
	}

	double totalInterest() {
		double total = 0;
		for (Client* cli : clients) {
			total = total + cli->getInterest();
		}
		return total;
	}


};

int main() {
	string op;
	int type, index;
	double amount=0.0;
	string name;
	Client* client;
	vector<Account*> accounts;
	BankManager bankManager;
	while (true) {
		cin >> op;
		if (op == "end") {
			break;
		}
		else if (op == "createAccount") {
			Account* account;
			cin >> type;

			switch (type) {
			case 0:
				account = new Check(accounts.size());
				accounts.push_back(account);
				break;
			case 1:
				account = new Save(accounts.size());
				accounts.push_back(account);
				break;
			default:
				account = new Maxi_Savings(accounts.size());
				accounts.push_back(account);
			}
		}
		else if (op == "createCustomer") {
			cin >> name;
			client = new Client(name);
			bankManager.addClient(client);
		}
		else if (op == "addToCustomer") {
			cin >> index >> name;
			client = bankManager.getClient(name);
			client->addAccount(accounts[index]);
		}
		else if (op == "accountDeposit") {
			cin >> index >> amount;
			if (amount > 0) {
				accounts[index]->deposit(amount);
			}else{
				cout << "amount must be greater than zero" << endl;
			}
		}
		else if (op == "accountWithdraw") {
			cin >> index >> amount;
			if (amount > 0) {
				accounts[index]->withdraw(amount);
			}
			else {
				cout << "amount must be greater than zero" << endl;
			}
		}
		else if (op == "sumTransactions") {
			cin >> index;
			double temp = accounts[index]->sumTranctions();
			cout.setf(ios::fixed);
			cout << setprecision(1) <<temp << endl;
		}
		else if (op == "numberOfAccount") {
			cin >> name;
			cout << bankManager.getClient(name)->getNumOfAccounts();
		}
		else if (op == "totalInterestEarned") {
			cin >> name;
			double temp = bankManager.getClient(name)->getInterest();
			cout.setf(ios::fixed);
			cout << setprecision(1)<< temp << endl;
		}
		else if (op == "getStatement") {
			cin >> name;
			bankManager.getClient(name)->showStatement();
		}
		else if (op == "banktotalInserstPaid") {
			cout.setf(ios::fixed);
			cout <<setprecision(1)<< bankManager.totalInterest()<<endl;
		}
		else if (op == "customsum") {
			bankManager.showClientSum();
		}
	}
	getchar();
	getchar();
}