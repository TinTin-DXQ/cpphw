#include <iostream>
using namespace std;

class DrinkOverflowException:public exception {
public:
	const char* what() const throw()
	{
		return "DrinkOverflow";
	}
}doverflow;

class DrinkNotFoundException:public exception {
public:
	const char* what() const throw(){
		return "DrinkNotFound";
	}
}dnotfound;

class Product {
public:
	int num;
	Product() :num(0){}
	virtual void addDrink(int addNum) = 0;
	virtual void buy() = 0;
	virtual int getNum() {
		return num;
	}
	virtual void setNum(int n) {
		num = n;
	}
};

class Coffee:public Product {
public:
	Coffee(){}
	int price=5;
	void addDrink(int addNum){
		setNum(getNum() + addNum);
	}
	void buy() {
		try {
			if (getNum() < 1) {
				throw dnotfound;
			}
			else {
				cout << "coffee:" << price << endl;
				setNum(getNum() - 1);
			}
		}
		catch (exception& e) {
			cout << "coffee is not found" << endl;
		}
	}
};

class Milk :public Product {
public:
	Milk(){}
	int price = 4;
	void addDrink(int addNum) {
		setNum(getNum() + addNum);
	}
	void buy() {
		try {
			if (getNum() < 1) {
				throw dnotfound;
			}
			else {
				cout << "milk:" << price << endl;
				setNum(getNum() - 1);
			}
		}
		catch (exception& e) {
			cout << "milk is not found" << endl;
		}
	}
};

class Tea :public Product {
public:
	Tea(){}
	int price = 3;
	void addDrink(int addNum) {
		setNum(getNum() + addNum);
	}
	void buy() {
		try {
			if (getNum() < 1) {
				throw dnotfound;
			}
			else {
				cout << "tea:" << price << endl;
				setNum(getNum() - 1);
			}
		}
		catch (exception& e) {
			cout << "tea is not found" << endl;
		}
	}
};

class Beer :public Product {
public:
	Beer(){}
	int price = 6;
	void addDrink(int addNum) {
		setNum(getNum() + addNum);
	}
	void buy() {
		try {
			if (getNum() < 1) {
				throw dnotfound;
			}
			else {
				cout << "beer:" << price << endl;
				setNum(getNum() - 1);
			}
		}
		catch (exception& e) {
			cout << "beer is not found" << endl;
		}
	}
};

class singleton{
protected:
	singleton() {}
	singleton(const singleton&);
public:
	Coffee coffee;
	Milk milk;
	Tea tea;
	Beer beer;
	static singleton *instance() {
		return m_instance == NULL ? m_instance = new singleton : m_instance;
	}
private:
	static singleton * m_instance;
};
singleton*  singleton ::m_instance = NULL;

class factory {
public:
	static Product *getDrink(int drinkType) {
		switch (drinkType) {
		case 1:
			return &singleton::instance()->coffee;
			break;
		case 2:
			return &singleton::instance()->milk;
			break;
		case 3:
			return &singleton::instance()->tea;
			break;
		default:
			return &singleton::instance()->beer;
		}
	}
};

int main() {
	factory fac;
	int total = 0;
	int type;
	int drink;
	int number;
	Product *product;
	while (true) {
		cin >> type;
		if (type == 1) {
			cin >> drink >> number;
			product = fac.getDrink(drink);
			try {
				total = total + number;
				if ( total > 10) {
					throw doverflow;
				}
				else {
					product->addDrink(number);
				}
			}
			catch(exception& e){
				cout << "DrinkOverflow" <<endl;
			}
		}
		else if (type == 2) {
			cin >> drink;
			total = total - 1;
			product = fac.getDrink(drink);
			product->buy();
		}
		else {
			break;
		}
	}
	getchar();
	getchar();
}