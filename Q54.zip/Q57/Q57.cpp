#include <iostream>
#include <list>
#include <string>
using namespace std;

class Role {
public:
	int id;
	int times;
	string name;
	int hp;
	int atk;
	int isAlive=1;
	virtual void getPower()=0;
	virtual void getHurt(int hurt)=0;
	int getId() {
		return id;
	}
	void setTimes(int t) {
		times = t;
	}
	void setId(int n) {
		id = n;
	}
	void setName(string na) {
		name = na;
	}
	void sethp(int h) {
		hp = h;
	}
	void setatk(int a) {
		atk = a;
	}
	void setAlive(int l) {
		isAlive = l;
	}
	int gethp() {
		return hp;
	}
	int getatk() {
		return atk;
	}
	int getAlive() {
		return isAlive;
	}
};
class Warrior:public Role{
public:
	Warrior() {
		Role::setId(1);
		Role::setName("Warrior");
		Role::sethp(12);
		Role::setatk(2);
		Role::setAlive(1);
		Role::setTimes(1);
	}
	void getPower() {
		int tempHp = Role::gethp() + 1;
		Role::sethp(tempHp);
	}
	void getHurt(int hurt) {
		int tempHp = Role::gethp()-hurt;
		Role::sethp(tempHp);
		if(tempHp<1){
			Role::setAlive(0);
		}
		/*else {
			getPower();
		}*/
	}
};

class Magician:public Role{
public:
	Magician() {
		Role::setId(2);
		Role::setName("Magician");
		Role::sethp(2);
		Role::setatk(6);
		Role::setAlive(1);
		Role::setTimes(0);
	}
	void getPower() {
		Role::sethp(2);
		Role::setAlive(1);
	}
	void getHurt(int hurt) {
		int tempHp = Role::gethp() - hurt;
		Role::sethp(tempHp);
		if (tempHp < 1) {
			Role::setAlive(0);
		}
	}
};

class Leader:public Role{
public:
	Leader() {
		Role::setId(3);
		Role::setName("Leader");
		Role::sethp(6);
		Role::setatk(6);
		Role::setAlive(1);
		Role::setTimes(1);
	}
	void getPower() {
		int tempAtk = Role::getatk() + 1;
		Role::setatk(tempAtk);
	}
	void getHurt(int hurt) {
		int tempHp = Role::gethp() - hurt;
		Role::sethp(tempHp);
		if (tempHp < 1) {
			Role::setAlive(0);
		}/*else {
			getPower();
		}*/
	}
};


class Fight {
public:
	list<Role*> roleList;
	friend Fight& operator+=(Fight& fight,Role*& role);
};

Fight& operator+=(Fight& fight, Role*& role){
	fight.roleList.push_back(role);
	return fight;
}

class Battle {
public:
	Role* role1;
	Role* role2;
	Battle(Role* role1,Role* role2):role1(role1),role2(role2){}

	int oneBattle() {
		while (role1->getAlive()==1 && role2->getAlive()==1) {
			int hurt1 = role1->atk;
			int hurt2 = role2->atk;
			role1->getHurt(hurt2);
			role2->getHurt(hurt1);
			//cout << hurt1 << " hu " << hurt2 << endl;
			if (role1->getId() == 2 && role1->times == 0) {
				role1->getPower();
				role1->setTimes(1);
			}
			if (role2->getId() == 2 && role2->times == 0) {
				role2->getPower();
				role2->setTimes(1);
			}
			if (role1->getAlive() == 1 && role1->getId() != 2) {
				role1->getPower();
			}
			if (role2->getAlive() == 1 && role2->getId() != 2) {
				role2->getPower();
			}
		}
		//cout << role1->getAlive() << " live " << role2->getAlive() << " " << endl;
		//cout << role1->hp << " hp " << role2->hp<< " " << endl;
		if (role1->isAlive == 0&&role2->isAlive==0) {
			return 3;
		}
		else if(role1->isAlive==0){
			return 2;
		}
		else{
			return 1;
		}
	}
};

int main() {
	int num;
	cin >> num;
	Fight fight1;
	Fight fight2;
	for (int i = 0; i < num; ++i) {
		Role* role;
		int x;
		cin >> x;
		switch (x){
		case 1:
			role = new Warrior;
			fight1 += role;
			break;
		case 2:
			role = new Magician;
			fight1 += role;
			break;
		default:
			role = new Leader;
			fight1 += role;
			break;
		}
	}
	for (int i = 0; i < num; ++i) {
		Role* role;
		int y;
		cin >> y;
		//cout << y << " ";
		switch (y) {
		case 1:
			role = new Warrior;
			fight2 += role;
			break;
		case 2:
			role = new Magician;
			fight2 += role;
			break;
		default:
			role = new Leader;
			fight2 += role;
			break;
		}
	}
	int numfight1 = fight1.roleList.size();
	int numfight2 = fight2.roleList.size();
	while(numfight1>0&&numfight2>0){
		Role* temp1 = fight1.roleList.front();
		Role* temp2 = fight2.roleList.front();
		//cout << temp1->id << " ";
		//cout << temp2->id << endl;
		Battle* battle=new Battle(temp1,temp2);
		int isWin = battle->oneBattle();
		//cout << isWin << endl;
		if (isWin == 3) {
			fight1.roleList.pop_front();
			fight2.roleList.pop_front();
		}
		else if (isWin == 2) {
			fight1.roleList.pop_front();
		}
		else {
			fight2.roleList.pop_front();
		}
		//cout << i << endl;
		numfight1 = fight1.roleList.size();
		numfight2 = fight2.roleList.size();
	}
	numfight1 = fight1.roleList.size();
	numfight2 = fight2.roleList.size();
	if (numfight1 > 0) {
		for (int i = 0; i < numfight1-1; ++i) {
			cout << fight1.roleList.front()->name << " " << fight1.roleList.front()->atk << " " << fight1.roleList.front()->hp<<endl;
			fight1.roleList.pop_front();
		}
		cout << fight1.roleList.front()->name << " " << fight1.roleList.front()->atk << " " << fight1.roleList.front()->hp;
	}
	if (numfight2 > 0) {
		for (int i = 0; i < numfight2; ++i) {
			cout << fight2.roleList.front()->name << " " << fight2.roleList.front()->atk << " " << fight2.roleList.front()->hp<<endl;
			fight2.roleList.pop_front();
		}
		cout << fight2.roleList.front()->name << " " << fight2.roleList.front()->atk << " " << fight2.roleList.front()->hp;
	}
	if (numfight1 == numfight2) {
		cout << "All Dead";
	}
	getchar();
	getchar();
}