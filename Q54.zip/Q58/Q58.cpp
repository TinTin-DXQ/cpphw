#include <iostream>
using namespace std;

class Chess {
public:
	int x;
	int o;
	Chess() :x(1), o(-1) {}
};

class Board {
public:
	int n;
	int m;
	int* bo;

	Board(int n, int m) :n(n), m(m) {
		bo = new int(n*n);
		for (int i = 0; i < n*n; ++i) {
			bo[i] = 0;
		}
	}

	void setChess(int x, int y, int xo) {
 		int temp = x*n + y;
		Chess* chess = new Chess;
		if (xo == -1) {
			bo[temp] = chess->o;
		}
		else {
			bo[temp] = chess->x;
		}
	}

	int isSuccess(int x, int y) {
		int xt;
		int yt;
		for (int i = 0; i < m; ++i) {
			int isTop = 0;
			int isLeft = 0;
			int isLeftTop = 0;
			int isLeftDown = 0;
			//��ֱ
			xt = x + i;
			yt = y;
			if (xt >= 0 && xt < n && yt >= 0 && yt < n) {
				for (int j = 0; j < m; ++j) {
					int tick = (xt - j)*n + yt;
					if (tick >= 0 && tick < n*n) {
						isTop = isTop + bo[tick];
						//break;
					}
					else {
						break;
					}
				}
				if (isTop == m) {
					return 1;
				}
				else if (isTop + m == 0) {
					return -1;
				}

			}
			else {
				break;
			}
			//ˮƽ
			xt = x;
			yt = y + i;
			if (xt >= 0 && xt < n && yt >= 0 && yt < n) {
				for (int j = 0; j < m; ++j) {
					int tick = xt * j*n + yt - j;
					if (tick >= 0 && tick < n*n) {
						isLeft = isLeft + bo[tick];
						//break;
					}
					else {
						break;
					}
				}
				if (isLeft == m) {
					return 1;
				}
				else if (isLeft + m == 0) {
					return -1;
				}
			}
			else {
				break;
			}
		

			//����
			xt = xt + i;
			yt = yt + i;
			if (xt >= 0 && xt < n && yt >= 0 && yt < n) {
				for (int j = 0; j < m; ++j) {
					int tick = (xt - j)*n + yt - j;
					if (tick >= 0 && tick < n*n) {
						isLeftTop = isLeftTop + bo[tick];
					}
					else {
						break;
					}
				}
				if (isLeftTop == m) {
					return 1;
				}
				else if (isLeftTop + m == 0) {
					return -1;
				}
			}
			else {
				break;
			}

			//����
			xt = xt - i;
			yt = yt + i;
			if (xt >= 0 && xt < n && yt >= 0 && yt < n) {
				for (int j = 0; j < m; ++j) {
					int tick = (xt + j)*n + yt - j;
					if (tick >= 0 && tick < n*n) {
						isLeftDown = isLeftDown + bo[tick];
					}
					else {
						break;
					}
				}
				if (isLeftDown == m) {
					return 1;
				}
				else if (isLeftDown + m == 0) {
					return -1;
				}
			}
			else {
				break;
			}
		}
		return 0;
	}
};


int main() {
	int step = 0;
	int x;
	int y;
	int nboard;
	int msuc;

	cin >> nboard;
	cin >> msuc;
	Board* board = new Board(nboard, msuc);
	Chess* ch = new Chess;
	int xo = -1;
	int res;
	while (step < nboard*nboard)
	{
		cin >> x;
		cin >> y;

		board->setChess(x, y, xo);
		res=board->isSuccess(x, y);
		/*for (int i = 0; i < nboard*nboard;++i) {
			cout << board->bo[i];
		}
		cout << endl;*/
		if (res == -1) {
			cout << "O Success";
			break;
		}
		else if (res == 1) {
			cout << "X Success";
			break;
		}
		/*for (int i = 0; i < nboard; ++i) {
			for (int j = 0; j < nboard; ++j) {
				cout << board->bo[i*nboard+j];
			}
			cout << endl;
		}*/
		xo = xo * -1;
		step++;
	}
	if (res == 0) {
		cin >> x;
		cin >> y;

		board->setChess(x, y, xo);
		res = board->isSuccess(x, y);
		/*for (int i = 0; i < nboard*nboard;++i) {
			cout << board->bo[i];
		}
		cout << endl;*/
		if (res == -1) {
			cout << "O Success";
		}
		else if (res == 1) {
			cout << "X Success";
		}
		else {
			cout << "Dogfall3";
		}
	}
	getchar();
	getchar();
}